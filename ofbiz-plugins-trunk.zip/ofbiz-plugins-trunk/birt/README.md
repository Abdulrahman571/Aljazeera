![Apache OFBiz® logo](https://camo.githubusercontent.com/b313d4ec52b77b5024e2988aaf76720258233e69/68747470733a2f2f6f6662697a2e6170616368652e6f72672f696d616765732f6f6662697a5f6c6f676f2e706e67)
![Birt Logo](http://www.eclipse.org/birt/img/logo/Birt-logo.png)
# Birt component
For more information about this component visit the [https://cwiki.apache.org/confluence/display/OFBIZ/Using+BIRT+with+OFBiz](https://cwiki.apache.org/confluence/display/OFBIZ/Using+BIRT+with+OFBiz) page in the OFBiz wiki

Information about the birt product can be found at: [http://www.eclipse.org/birt/](http://www.eclipse.org/birt/)

Information on the OFBiz Flexible Birt Reports are at [https://cwiki.apache.org/confluence/display/OFBIZ/Birt+Flexible+Reports](https://cwiki.apache.org/confluence/display/OFBIZ/Birt+Flexible+Reports) 