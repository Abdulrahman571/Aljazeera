<img src="https://camo.githubusercontent.com/b313d4ec52b77b5024e2988aaf76720258233e69/68747470733a2f2f6f6662697a2e6170616368652e6f72672f696d616765732f6f6662697a5f6c6f676f2e706e67" alt="Apache OFBiz" />

# MyPortal component
This component enables organisations to provide their users with a self service starting point.

Enabling both internal (employees) and external (customers, sub-contractors) to manage their own profile for the back-end applications of OFBiz™, register time spent on projects and manufacturing tasks and manage their schedule and tasks.

## Features

    Page management (application admin)
    Time registration
    Tasks execution
    Profile management


