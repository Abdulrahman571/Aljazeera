<img src="https://camo.githubusercontent.com/b313d4ec52b77b5024e2988aaf76720258233e69/68747470733a2f2f6f6662697a2e6170616368652e6f72672f696d616765732f6f6662697a5f6c6f676f2e706e67" alt="Apache OFBiz" />

# Assetmaint component
The asset management and maintenance application enables organisations to maintain a register of all kinds of assets. It enables them to plan maintenance and keep track of allocations and use. Integrates with the accounting module regarding depreciation bookings.


## Features

    Asset registration
    Maintenance planning
    Depreciation calculation and registration
    Meter registrations
    Allocation registration

